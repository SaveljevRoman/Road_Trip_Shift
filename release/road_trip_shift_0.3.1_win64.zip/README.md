# Road Trip Shift 0.3.1 experimental

[Русская версия](README_RU.md)

Close ATS, then copy the included bin folder into your game directory. Keep an existing INI when updating. The DLL alone uses built-in defaults.

[Installation, compatibility, settings and removal](docs/INSTALL.md) · [Установка на русском](docs/INSTALL_RU.md)

The new cruise protection still needs driving validation. Retain the licenses folder when redistributing this package. BUILD-INFO.json records the supported EXE and DLL hash.
