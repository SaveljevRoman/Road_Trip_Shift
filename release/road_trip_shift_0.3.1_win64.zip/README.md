# Road Trip Shift 0.3.1 experimental

[Русская версия](README_RU.md)

Close ATS, then copy the included bin folder into your game directory. Keep an existing INI when updating. The DLL alone uses built-in defaults.

[Installation, compatibility, settings and removal](docs/INSTALL.md) · [Установка на русском](docs/INSTALL_RU.md)

The new cruise protection still needs driving validation. Retain the licenses folder when redistributing this package. Tested on ATS 1.62.1.1 (Windows x64). BUILD-INFO.json records the tested EXE and DLL hash.
